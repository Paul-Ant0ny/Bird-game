from flask import Flask, render_template, Response
import pygame
import random
import io
import base64

app = Flask(__name__)

# Initialize Pygame
pygame.init()

# Set up the display
WIDTH = 320
HEIGHT = 480
screen = pygame.Surface((WIDTH, HEIGHT))

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
SKY_BLUE = (135, 206, 235)
GREEN = (76, 175, 80)
DARK_GREEN = (69, 160, 73)
LIGHT_GREEN = (139, 195, 74)

# Bird properties
BIRD_RADIUS = 20
bird_x = 50
bird_y = HEIGHT // 2
bird_velocity = 0
GRAVITY = 0.25
JUMP_STRENGTH = -5

# Pipe properties
PIPE_WIDTH = 50
PIPE_GAP = 180
pipes = []

# Game state
score = 0
game_over = False
game_started = False

# Load font
font = pygame.font.Font(None, 36)

# Create bird surface
bird_surf = pygame.Surface((BIRD_RADIUS * 2, BIRD_RADIUS * 2), pygame.SRCALPHA)
pygame.draw.circle(bird_surf, (255, 215, 0), (BIRD_RADIUS, BIRD_RADIUS), BIRD_RADIUS)
pygame.draw.circle(bird_surf, BLACK, (BIRD_RADIUS + 8, BIRD_RADIUS - 8), 2)
pygame.draw.arc(bird_surf, BLACK, (BIRD_RADIUS - 10, BIRD_RADIUS + 5, 20, 10), 3.14, 6.28, 2)
pygame.draw.polygon(bird_surf, (255, 99, 71), [(0, BIRD_RADIUS + 2), (BIRD_RADIUS - 15, BIRD_RADIUS - 2), (BIRD_RADIUS - 15, BIRD_RADIUS + 6)])

def create_pipe():
    gap_start = random.randint(50, HEIGHT - PIPE_GAP - 50)
    pipes.append({
        'x': WIDTH,
        'top': gap_start,
        'bottom': gap_start + PIPE_GAP
    })

def draw_bird(x, y, angle):
    rotated_bird = pygame.transform.rotate(bird_surf, angle)
    screen.blit(rotated_bird, (x - BIRD_RADIUS, y - BIRD_RADIUS))

def draw_pipes():
    for pipe in pipes:
        # Top pipe
        pygame.draw.rect(screen, GREEN, (pipe['x'], 0, PIPE_WIDTH, pipe['top']))
        pygame.draw.rect(screen, DARK_GREEN, (pipe['x'] + PIPE_WIDTH - 10, 0, 10, pipe['top']))
        pygame.draw.rect(screen, LIGHT_GREEN, (pipe['x'], pipe['top'] - 20, PIPE_WIDTH, 20))

        # Bottom pipe
        pygame.draw.rect(screen, GREEN, (pipe['x'], pipe['bottom'], PIPE_WIDTH, HEIGHT - pipe['bottom']))
        pygame.draw.rect(screen, DARK_GREEN, (pipe['x'] + PIPE_WIDTH - 10, pipe['bottom'], 10, HEIGHT - pipe['bottom']))
        pygame.draw.rect(screen, LIGHT_GREEN, (pipe['x'], pipe['bottom'], PIPE_WIDTH, 20))

def draw_score():
    score_text = font.render(f"Score: {score}", True, BLACK)
    screen.blit(score_text, (10, 10))

def draw_background():
    screen.fill(SKY_BLUE)
    # Draw clouds
    pygame.draw.circle(screen, WHITE, (50, 50), 25)
    pygame.draw.circle(screen, WHITE, (80, 60), 20)
    pygame.draw.circle(screen, WHITE, (110, 50), 25)
    pygame.draw.circle(screen, WHITE, (250, 80), 25)
    pygame.draw.circle(screen, WHITE, (280, 90), 20)
    pygame.draw.circle(screen, WHITE, (310, 80), 25)

def draw_title_screen():
    draw_background()
    s = pygame.Surface((WIDTH, HEIGHT))
    s.set_alpha(128)
    s.fill((0, 0, 0))
    screen.blit(s, (0, 0))

    title_font = pygame.font.Font(None, 48)
    title_text = title_font.render("Flappy Bird", True, WHITE)
    screen.blit(title_text, (WIDTH // 2 - title_text.get_width() // 2, HEIGHT // 2 - 100))

    instruction_font = pygame.font.Font(None, 24)
    instructions = ["Tap to flap", "Avoid pipes", "Score points"]
    for i, instruction in enumerate(instructions):
        text = instruction_font.render(instruction, True, WHITE)
        screen.blit(text, (WIDTH // 2 - text.get_width() // 2, HEIGHT // 2 - 30 + i * 40))

    start_text = font.render("Tap to start", True, WHITE)
    screen.blit(start_text, (WIDTH // 2 - start_text.get_width() // 2, HEIGHT // 2 + 120))

def reset_game():
    global bird_y, bird_velocity, pipes, score, game_over
    bird_y = HEIGHT // 2
    bird_velocity = 0
    pipes = []
    score = 0
    game_over = False

def update_game_state(jump):
    global bird_y, bird_velocity, score, game_over, game_started

    if not game_started:
        if jump:
            game_started = True
        else:
            return

    if game_over:
        if jump:
            reset_game()
        return

    if jump:
        bird_velocity = JUMP_STRENGTH

    # Update bird position
    bird_velocity += GRAVITY
    bird_y += bird_velocity

    # Check for collisions
    if bird_y + BIRD_RADIUS > HEIGHT:
        game_over = True

    # Update pipes
    for pipe in pipes:
        pipe['x'] -= 1.5

        if pipe['x'] + PIPE_WIDTH < bird_x - BIRD_RADIUS and not pipe.get('passed', False):
            score += 1
            pipe['passed'] = True

        if (bird_x + BIRD_RADIUS > pipe['x'] and
            bird_x - BIRD_RADIUS < pipe['x'] + PIPE_WIDTH and
            (bird_y - BIRD_RADIUS < pipe['top'] or bird_y + BIRD_RADIUS > pipe['bottom'])):
            game_over = True

    # Remove off-screen pipes
    pipes[:] = [pipe for pipe in pipes if pipe['x'] + PIPE_WIDTH > 0]

    # Create new pipes
    if len(pipes) == 0 or pipes[-1]['x'] < WIDTH - 200:
        create_pipe()

def generate_frame():
    draw_background()

    if not game_started:
        draw_title_screen()
    else:
        draw_pipes()
        draw_bird(bird_x, bird_y, bird_velocity * -2)
        draw_score()

        if game_over:
            s = pygame.Surface((WIDTH, HEIGHT))
            s.set_alpha(128)
            s.fill((0, 0, 0))
            screen.blit(s, (0, 0))

            game_over_text = font.render("Game Over", True, WHITE)
            screen.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 2 - 50))

            score_text = font.render(f"Score: {score}", True, WHITE)
            screen.blit(score_text, (WIDTH // 2 - score_text.get_width() // 2, HEIGHT // 2))

            restart_text = font.render("Tap to restart", True, WHITE)
            screen.blit(restart_text, (WIDTH // 2 - restart_text.get_width() // 2, HEIGHT // 2 + 50))

    # Convert the surface to a base64 encoded string
    buffer = io.BytesIO()
    pygame.image.save(screen, buffer, "PNG")
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
    return f"data:image/png;base64,{image_base64}"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/game_state')
def game_state():
    return {
        'frame': generate_frame(),
        'score': score,
        'game_over': game_over
    }

@app.route('/jump')
def jump():
    update_game_state(True)
    return '', 204

@app.route('/update')
def update():
    update_game_state(False)
    return '', 204

if __name__ == '__main__':
    app.run(debug=True)